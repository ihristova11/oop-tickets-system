var indexSectionsWithContent =
{
  0: "abcefghiloprstuvw",
  1: "abcefhiorstuv",
  2: "c",
  3: "eghiprstvw",
  4: "l"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables"
};

