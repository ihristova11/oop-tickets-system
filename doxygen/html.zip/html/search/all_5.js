var searchData=
[
  ['getevent_16',['getEvent',['../class_store.html#ae7094f6bbe95ea9510637bac2ad19514',1,'Store']]],
  ['gethallwithid_17',['getHallWithId',['../class_store.html#ad0c3c398527bb654c83cd9f8986a7707',1,'Store']]],
  ['getinstance_18',['getInstance',['../class_engine.html#a4fbdd2df29e30dd08de3c285cee8c128',1,'Engine']]],
  ['getticketbycode_19',['getTicketByCode',['../class_store.html#a8b5d5aa9675b295b453892ea576188dc',1,'Store']]],
  ['getticketind_20',['getTicketInd',['../class_store.html#a6bebcc9e53c37ab371b587fd2ca155dd',1,'Store']]]
];
